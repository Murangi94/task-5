![Black Minimal Motivation Quote LinkedIn Banner (2)](https://user-images.githubusercontent.com/90236635/232291203-4d6bed99-30e5-4837-96b6-98bbbef053d3.png)

# simple-weather-website

## About
 - This is a simple weather website.
 -  Pure HTML, CSS, JavaScript used.
 
 ## To see the project
[Weather website](https://simple-weather-website.netlify.app/)

## Preview

<img src="https://user-images.githubusercontent.com/90236635/178144287-2d0c35f4-0b40-4b2c-bdfe-d874777eb87b.png" width="75%">
